//
//  CategoryCollectionViewCell.swift
//  QuizLett
//
//  Created by Yash Saxena on 04/03/23.
//

import UIKit

class CategoryCollectionViewCell: UICollectionViewCell {
    
}
