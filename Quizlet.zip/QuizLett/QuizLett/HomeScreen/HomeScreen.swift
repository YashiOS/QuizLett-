//
//  HomeScreen.swift
//  QuizLett
//
//  Created by Yash Saxena on 25/02/23.
//

import Foundation
import UIKit

class HomeScreen: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    let spaceBetweenSections = 50
    
    struct imageData {
        let imageName: String
    }
    
    let data: [imageData] = [
    imageData(imageName: "ios"),
    imageData(imageName: "android")
    
    ]
    let images = [UIImage(named: "ios"), UIImage(named: "android")]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let imagesData = data[indexPath.row]
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "tableViewCell", for: indexPath) as? CategoryTableViewCell else { return fatalError("Unable to fetch it") as! UITableViewCell }
        
        tableView.rowHeight = 165
        cell.layer.borderWidth = 0.5
        cell.layer.cornerRadius = 25
        cell.layer.borderColor = UIColor.black.cgColor
        cell.categoryImageView.image = UIImage(named: imagesData.imageName)
        cell.categoryImageView.layer.cornerRadius = 25
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 0 {
            let storyBoard = UIStoryboard(name: "QuestionScreen", bundle: nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "questionsScreen")
            present(nextViewController, animated: true)
        }
        if indexPath.row == 1 {
            let storyBoard = UIStoryboard(name: "QuestionScreen", bundle: nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "questionsScreen")
            present(nextViewController, animated: true)
        }
        
        return
    }


    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var selectCategoryLabel: UILabel!
    @IBOutlet weak var lineView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        tableView.delegate = self
        tableView.dataSource = self
        
    }
    
    func setupUI() {
        
        lineView.layer.borderWidth = 10
        lineView.layer.borderColor = UIColor.black.cgColor
        selectCategoryLabel.text = "Select Category"
        selectCategoryLabel.numberOfLines = 2
        selectCategoryLabel.font = .boldSystemFont(ofSize: 30)
        selectCategoryLabel.textAlignment = .center
    }
    
    
    @IBAction func backPressed(_ sender: Any) {
        let storyBoard = UIStoryboard.init(name: "TermsAndCondition", bundle: nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "termAndConditions")
        present(nextViewController, animated: true)
    }
    
    
   
    
  
}
