//
//  ViewController.swift
//  QuizLett
//
//  Created by Yash Saxena on 16/02/23.
//

import UIKit
import GoogleSignIn
import FirebaseCore
import FirebaseAuth


class ViewController: UIViewController {
    
    var authentication: GIDGoogleUser!
    
    @IBOutlet weak var submitBTN: UIButton!
    @IBOutlet weak var googleSignIn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        otptextField.isHidden = true
        
    }
    
    func setupUI() {
        submitBTN.layer.cornerRadius = 20
        submitBTN.setTitle("Submit", for: .normal)
        submitBTN.setTitleColor(UIColor.black, for: .normal)
        googleSignIn.setTitle("", for: .normal)
        googleSignIn.layer.borderWidth = CGFloat(2)
        googleSignIn.layer.borderColor = UIColor.black.cgColor
    }
    @IBOutlet weak var mobileNumberTextField: UITextField!
    @IBOutlet weak var otptextField: UITextField!
    
    var verification_id : String? = nil
    
    
    
    @IBAction func submitButtonCalled(_ sender: Any) {
        if (otptextField.isHidden) {
            if !mobileNumberTextField.text!.isEmpty {
                Auth.auth().settings?.isAppVerificationDisabledForTesting = false
                
                PhoneAuthProvider.provider().verifyPhoneNumber(mobileNumberTextField!.text!, uiDelegate: nil, completion: { verification_id, error in
                    if (error != nil) {
                        return
                    } else {
                        self.verification_id = verification_id
                        self.otptextField.isHidden = false
                        
                    }
                })
            } else {
                print("Please enter your mobile Number")
            }
        } else {
            if verification_id != nil {
                let credentials = PhoneAuthProvider.provider().credential(withVerificationID: verification_id!, verificationCode: otptextField.text!)
                Auth.auth().signIn(with: credentials) { authData, error in
                    if (error != nil) {
                        print(error?.localizedDescription)
                    } else {
                        let storyBoard = UIStoryboard(name: "TermsAndCondition", bundle: nil)
                        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "termAndConditions")
                        self.present(nextViewController, animated: true )
                        print("Authentication success with" + (authData?.user.phoneNumber ?? "enterNumber"))
                    }
                }
            } else {
                print("error in getting otp")
            }
        }
        
        
        
    }
    
    @IBAction func googleSignInButton(_ sender: Any) {
        //        GIDSignIn.sharedInstance.signIn(withPresenting: self)
        googleSign()
    }
    
    func googleSign() {
        guard let clientID = FirebaseApp.app()?.options.clientID else {return}
        
        let config = GIDConfiguration(clientID: clientID)
        GIDSignIn.sharedInstance.configuration = config
        
        
        
        GIDSignIn.sharedInstance.signIn(withPresenting: self) { [unowned self] result, error in
            guard error == nil else {
                
                return print(error)
            }
            guard let user = result?.user,
                  let idToken = user.idToken?.tokenString
                    
            else {
                
                return print(error)
            }
            
            let credential = GoogleAuthProvider.credential(withIDToken: idToken, accessToken: user.idToken?.tokenString ?? "")
            //
            Auth.auth().signIn(with: credential) { result, error in
                //
                if error == nil  {
                    let storyBoard = UIStoryboard(name: "TermsAndCondition", bundle: nil)
                    let nextViewController = storyBoard.instantiateViewController(withIdentifier: "termAndConditions")
                    present(nextViewController, animated: true)
                    
                } else {
                    return print(result)
                }
                
                
            }
        }
        
    }
    
}

