//
//  QuestionAnswerScreen.swift
//  QuizLett
//
//  Created by Yash Saxena on 18/03/23.
//

import Foundation
import UIKit

class QuestionAnswerScreen: UIViewController {
    
    @IBOutlet var scoreLabel: UILabel!
    @IBOutlet var answerButtonTwo: UIButton!
    @IBOutlet var answerButtonFour: UIButton!
    @IBOutlet var answerButtonThree: UIButton!
    @IBOutlet var answerButtonOne: UIButton!
    
    var randomQuestion: (Question: String, Options:[String], Answer: String)!
    
    var strike: Int  = 0
    var userScore: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        newQuestion()
        questionLabel.numberOfLines = 0
        questionLabel.lineBreakMode = .byWordWrapping
    }
    
    @IBOutlet var questionLabel: UILabel!
   
  
    @IBAction func buttonOne(_ sender: Any) {
        
        checkAnswer(selectedAnswer: "d")
    }
    
    @IBAction func buttonTwo(_ sender: Any) {
        checkAnswer(selectedAnswer: "a")
    }
    
    
    @IBAction func buttonThree(_ sender: Any) {
        checkAnswer(selectedAnswer: "a")
    }
    
    
    @IBAction func buttonFour(_ sender: Any) {
        checkAnswer(selectedAnswer: "a")
    }
    
    @IBAction func submitButtonClicked(_ sender: Any) {
        let storyBoard = UIStoryboard(name: "ThankyouScreen", bundle: nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "thankYouScreen")
        present(nextViewController, animated: true)
        
        
    }
    
    @IBAction func backButtonPressed(_ sender: Any) {
        
        let storyBoard = UIStoryboard(name: "HomeScreen", bundle: nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "homeScreen")
        present(nextViewController, animated: true)
    }
    
    
    let quiz = [(
        
          Question: "What is the purpose of 'guard' statement in Swift?",
          Options: [
            "Unwrap",
            "Error",
            "Execute",
            "Exit"],
          Answer: "d"
        ),
                
              (
                Question: "What is the difference between 'weak' and 'strong' references in iOS?",
                 Options: [
                   "Weak",
                   "Strong",
                   "Class",
                   "Struct"],
                 Answer: "a"
              ),
                
               ( Question: "What is the difference between 'frame' and 'bounds' in iOS?",
                  Options: [
                    "Frame",
                    "Bounds",
                    "Same",
                    "Dynamic"],
                  Answer: "a"
               ),
                
                
                (
                    Question: "What is the difference between a 'struct' and a 'class' in Swift?",
                      Options: [
                        "Value",
                        "Reference",
                        "Same",
                        "Static"],
                      Answer: "a"
                )
    ]
    func checkAnswer(selectedAnswer: String) {
       
        randomQuestion = quiz.randomElement()
        if selectedAnswer == randomQuestion.Answer {
            print("Correct Answer")
            userScore += 5
            
        } else {
           strike += 1

                print("Incorrect Answer")
                userScore -= 3
            }
        
        newQuestion()
    }
    
    func newQuestion(){
        if (strike >= 3 ) {
            let storyBoard = UIStoryboard(name: "StrikeScreen", bundle: nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "strikeScreen")
            present(nextViewController, animated: true)
            print("oops you lose")
        }
        scoreLabel.text = "\(userScore)"
        // Choose a random question from the array
         randomQuestion = quiz.randomElement()!
        
        questionLabel.text = randomQuestion.Question
        answerButtonOne.setTitle(randomQuestion.Options[0], for: .normal)
        answerButtonTwo.setTitle(randomQuestion.Options[1], for: .normal)
        answerButtonThree.setTitle(randomQuestion.Options[2], for: .normal)
        answerButtonFour.setTitle(randomQuestion.Options[3], for: .normal)
        
        
    }
}
