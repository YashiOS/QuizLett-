//
//  QuestionsScreen.swift
//  QuizLett
//
//  Created by Yash Saxena on 15/03/23.
//

import Foundation
import UIKit

class QuestionsScreen: UIViewController {
    
    @IBOutlet var questionLabel: UILabel!
    @IBOutlet var answerButtonTwo: UIButton!
    
    @IBOutlet var submitButton: UIButton!
    @IBOutlet var answerButtonFour: UIButton!
    @IBOutlet var answerButtonThree: UIButton!
    @IBOutlet var answerButtonOne: UIButton!
    
    var Questions = [Response]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
        
    }
    
    
    
    func setupUI() {
        let url = "http://apnapayment.com/quiz.php?company_id=23"
        getData(from: url)
        
        
    }
    
    struct Response : Codable {
        let id : String?
        let quiz_ques : String?
        let company_id : String?
        let answer : String?
        let optiona : String?
        let optionb : String?
        let optionc : String?
        let optiond : String?

        enum CodingKeys: String, CodingKey {

            case id = "id"
            case quiz_ques = "quiz_ques"
            case company_id = "company_id"
            case answer = "answer"
            case optiona = "optiona"
            case optionb = "optionb"
            case optionc = "optionc"
            case optiond = "optiond"
        }

        init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            id = try values.decodeIfPresent(String.self, forKey: .id)
            quiz_ques = try values.decodeIfPresent(String.self, forKey: .quiz_ques)
            company_id = try values.decodeIfPresent(String.self, forKey: .company_id)
            answer = try values.decodeIfPresent(String.self, forKey: .answer)
            optiona = try values.decodeIfPresent(String.self, forKey: .optiona)
            optionb = try values.decodeIfPresent(String.self, forKey: .optionb)
            optionc = try values.decodeIfPresent(String.self, forKey: .optionc)
            optiond = try values.decodeIfPresent(String.self, forKey: .optiond)
        }

    }
    
    private func getData(from url: String) {
        
        
        URLSession.shared.dataTask(with: URL(string: url)!, completionHandler: { (data, response, error) in
            guard let data = data, error == nil else{
                print("gone wrong")
                return
            }
            var result :[Response]?
            do {
                result = try JSONDecoder().decode([Response].self, from: data)
                
            } catch {
                print(error)
            }
            
            guard let json = result else {
                return
            }
            print(result?.first?.id)
            result?.forEach { results in print(results.quiz_ques, results.optiona)}
            DispatchQueue.main.async {
                    self.questionLabel.text = result?.first?.quiz_ques
                    self.answerButtonOne.setTitle(result?.first?.optiona, for: .normal)
                
                
                    self.answerButtonTwo.setTitle(result?.first?.optionb, for: .normal)
                    self.answerButtonThree.setTitle(result?.first?.optionc, for: .normal)
                    self.answerButtonFour.setTitle(result?.first?.optiond, for: .normal)
            }
            
       }).resume()
        
       
        
    }
    
}
