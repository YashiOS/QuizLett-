//
//  ThankyouScreenViewController.swift
//  QuizLett
//
//  Created by Yash Saxena on 18/03/23.
//

import Foundation
import UIKit
import Lottie


class ThankyouScreenViewController: UIViewController {
    
    

    @IBOutlet var lottieView: LottieAnimationView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupAnimation()
        
    }
    @IBAction func homeScreenButton(_ sender: Any) {
        let storyBoard = UIStoryboard(name: "HomeScreen", bundle: nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "homeScreen")
        present(nextViewController, animated: true)
    }
    
    private func setupAnimation() {
        let animationView = LottieAnimationView(name: "137999-success")
        animationView.frame = CGRect(x: 0, y: 0, width: 400, height: 400)
        animationView.center = self.view.center
        animationView.contentMode = .scaleAspectFit
        view.addSubview(animationView)
        animationView.play()
        animationView.loopMode = .loop
    }
}
