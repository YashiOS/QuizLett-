//
//  StrikeScreen.swift
//  QuizLett
//
//  Created by Yash Saxena on 18/03/23.
//

import Foundation
import UIKit

class StrikeScreen: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    @IBOutlet var strikeLabel: UILabel!
    
    
    func setupUI() {
        strikeLabel.text = "Oops you LOSE! Better Luck Next Time"
        strikeLabel.lineBreakMode = .byWordWrapping
        strikeLabel.numberOfLines = 0
    }
    @IBAction func dashboardButton(_ sender: Any) {
        
        let storyBoard = UIStoryboard(name: "HomeScreen", bundle: nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "homeScreen")
        present(nextViewController, animated: true)
    }
}
