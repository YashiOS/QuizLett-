//
//  TermsAndConditions.swift
//  QuizLett
//
//  Created by Yash Saxena on 25/02/23.
//

import Foundation
import UIKit
import Firebase

class TermsAndConditions : UIViewController {
    @IBOutlet weak var getStarted: UIButton!
    @IBOutlet weak var termstwoLabel: UILabel!
    
    @IBOutlet weak var termFourlabel: UILabel!
    @IBOutlet weak var termThreeLabel: UILabel!
    @IBOutlet weak var termsLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        showAlert()
        setupUI()
    }
    
    
    func setupUI() {
        termsLabel.text = "1. Please take the test on your desktop or laptop."
        termstwoLabel.text = " 2. Choose a quiet location where you will not be interrupted."
        termThreeLabel.text = " 3. Ensure you have a reliable internet connection before starting the test."
        termFourlabel.text = " 4. Don't switch the tabs otherwise exam will be stopped. "
        termsLabel.numberOfLines = 5
        termstwoLabel.numberOfLines = 5
        termThreeLabel.numberOfLines = 5
        termFourlabel.numberOfLines = 5
        termsLabel.font = .boldSystemFont(ofSize: 15)
        termstwoLabel.font = .boldSystemFont(ofSize: 15)
        termThreeLabel.font = .boldSystemFont(ofSize: 15)
        termFourlabel.font = .boldSystemFont(ofSize: 15)
    }
    
    @IBAction func getStartedButtonClicked(_ sender: Any) {
        
        if getStarted.isEnabled == true {
            
            let storyBoard = UIStoryboard(name: "HomeScreen", bundle: nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "homeScreen")
            present(nextViewController, animated: true)
            
            
            
        } else {
            
            showAlert()
        }
    }
    
    
    
    func showAlert() {
        let alert = UIAlertController(title: "Read the Terms and Conditions", message: "Press the Get Started", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.default))
        
        DispatchQueue.main.async {
            self.present(alert, animated: true)
        }
    }
    
    
}
